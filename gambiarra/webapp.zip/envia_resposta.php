<?php
require "init.php";
$id_questao = $_POST["id_questao"];
$id_cliente = $_POST["id_cliente"];
$alternativa = $_POST["alternativa"];
$sql_query = "INSERT INTO responde (alternativa, usuario_id, questoes_id) VALUES('$alternativa','$id_cliente', '$id_questao');";
mysqli_query($con,$sql_query);
//if(mysqli_query($con,$sql_query))
//echo "<h3> Data insertion Sucess... </h3>";
//else
//echo "Data insertion error...".mysqli_error($con);
mysqli_close($con);
?>

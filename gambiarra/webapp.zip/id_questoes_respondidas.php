<?php
require "init.php";
$id = $_POST["id"];
$sql_query = "SELECT questoes_id FROM responde WHERE usuario_id = '$id';";
$result = mysqli_query($con, $sql_query);
$quant = mysqli_num_rows($result);
for($i=0; $i < $quant; $i++){
	$row = mysqli_fetch_assoc($result);
	echo $row["questoes_id"]."\n";
}
mysqli_close($con);
?>

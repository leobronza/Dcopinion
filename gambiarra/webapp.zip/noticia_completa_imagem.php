<?php
require "init.php";
$id = $_POST["id"];
$sql_query = "SELECT img FROM noticias WHERE id = '$id';";
$result = mysqli_query($con, $sql_query);
$row = mysqli_fetch_assoc($result);
echo $row["img"];
mysqli_close($con);
?>



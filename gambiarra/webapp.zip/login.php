<?php
require "init.php";
$email = $_POST["email"];
$senha = $_POST["senha"];
$sql_query = "SELECT id FROM usuario WHERE email = '$email' AND senha = '$senha';";
$resultado = mysqli_query($con, $sql_query);
if(mysqli_num_rows($resultado) > 0){
	$row = mysqli_fetch_assoc($resultado);
	echo $row["id"];
}
else 
	echo "ERRO";
mysqli_close($con);
?>

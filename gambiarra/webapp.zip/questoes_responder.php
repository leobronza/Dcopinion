<?php
// Arrumar
require "init.php";
$id = $_POST["id"];
$sql_query = "SELECT id, titulo, tipo FROM questoes WHERE (SELECT questoes_id FROM responde where usuario_id = '$id') != questoes.id AND categoria = (SELECT categoria FROM usuario WHERE id = '$id') OR (select questoes_id FROM responde where usuario_id = '$id') IS NULL AND categoria = (SELECT categoria FROM usuario WHERE id = '$id')";
$result = mysqli_query($con, $sql_query);

$quant = mysqli_num_rows($result);
for($i=0; $i < $quant; $i++){
	$row = mysqli_fetch_assoc($result);
	echo $row["id"];
	echo "\n";
	echo $row["titulo"];
	echo "\n";
	echo $row["tipo"];
	echo "\n";
}
mysqli_close($con);
?>

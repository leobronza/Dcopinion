<?php
require "init.php";
$id = $_POST["id"];
$sql_query = "SELECT titulo, corpo, link FROM noticias WHERE id = '$id';";
$result = mysqli_query($con, $sql_query);
$row = mysqli_fetch_assoc($result);        
echo $row["titulo"]."\n";
echo $row["corpo"]."\n";
echo $row["link"];
mysqli_close($con);
?>


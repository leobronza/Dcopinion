<?php
require "init.php";
$sql_query = "SELECT id, titulo FROM noticias;";
$resultado = mysqli_query($con, $sql_query);
$quant = mysqli_num_rows($resultado);
for($i=0; $i < $quant; $i++){
	$row = mysqli_fetch_assoc($resultado);
	echo $row["id"]."\n";
	echo $row["titulo"]."\n";
}
mysqli_close($con);
?>

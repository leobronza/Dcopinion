<?php
//Arrumar
require "init.php";
$id = $_POST["id"];
$sql_query = "SELECT tipo FROM questoes WHERE id = '$id';";
$result = mysqli_query($con, $sql_query);
$row = mysqli_fetch_assoc($result);
$tipo = $row["tipo"];
if($tipo == 1)
	$sql_query = "SELECT questoes.id, titulo, corpo, a, t_a, b, t_b, c, t_c, d, t_d, e, t_e FROM questoes INNER JOIN resposta_a ON questoes.id = resposta_a.questoes_id WHERE questoes.id = '$id';";
else if($tipo == 2)
	$sql_query = "SELECT questoes.id, titulo, corpo, E1, E2, E3, E4, E5 FROM questoes INNER JOIN resposta_e ON questoes.id = resposta_e.questoes_id WHERE questoes.id = '$id';";
$result = mysqli_query($con, $sql_query);
$row = mysqli_fetch_assoc($result);        
echo $row["titulo"]."\n";
echo $row["corpo"]."\n";
if($tipo == 1){
	echo $row["a"]."\n";
	echo $row["t_a"]."\n";
	echo $row["b"]."\n";
	echo $row["t_b"]."\n";
	echo $row["c"]."\n";
	echo $row["t_c"]."\n";
	echo $row["d"]."\n";
	echo $row["t_d"]."\n";
	echo $row["e"]."\n";
	echo $row["t_e"];
}else if($tipo == 2){
	echo $row["E1"]."\n";
	echo "<E>1"."\n";
	echo $row["E2"]."\n";
	echo "<E>2"."\n";
	echo $row["E3"]."\n";
	echo "<E>3"."\n";
	echo $row["E4"]."\n";
	echo "<E>4"."\n";
	echo $row["E5"]."\n";
	echo "<E>5"."\n";
}
mysqli_close($con);
?>


<?php
require "init.php";
$email = $_POST["email"];
$senha = $_POST["senha"];
$categoria = $_POST["categoria"];

$sql_query = "INSERT INTO usuario (email, senha, categoria) VALUES('$email','$senha', '$categoria');";
mysqli_query($con,$sql_query);
//if(mysqli_query($con,$sql_query))
//echo "<h3> Data insertion Sucess... </h3>";
//else
//echo "Data insertion error...".mysqli_error($con);
mysqli_close($con);
?>
